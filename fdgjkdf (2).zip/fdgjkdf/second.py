def calculate(month, balance, min_amount, annualInterestRate):
    while month <12:
        balance = balance - min_amount
        balance = balance + (annualInterestRate * balance)/1200
        month = month +1
    return balance
min_amount = 10
balance = input()
annualInterestRate = input()
while True:
      if calculate(0, balance, min_amount, annualInterestRate) <= 0:
          break
      min_amount = min_amount+10
print('Lowest Payment: ' + str(min_amount))